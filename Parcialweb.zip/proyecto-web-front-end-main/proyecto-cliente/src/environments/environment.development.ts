export const environment = {serverUrl: "http://localhost:8080"};
