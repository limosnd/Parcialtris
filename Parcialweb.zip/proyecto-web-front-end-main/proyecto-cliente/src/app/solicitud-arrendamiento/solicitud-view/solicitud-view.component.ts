import { Component } from '@angular/core';

@Component({
  selector: 'app-solicitud-view',
  templateUrl: './solicitud-view.component.html',
  styleUrl: './solicitud-view.component.css'
})
export class SolicitudViewComponent {

}
