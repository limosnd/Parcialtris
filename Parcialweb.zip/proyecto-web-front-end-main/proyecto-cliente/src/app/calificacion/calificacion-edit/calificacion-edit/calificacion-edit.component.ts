import { Component } from '@angular/core';

@Component({
  selector: 'app-calificacion-edit',
  templateUrl: './calificacion-edit.component.html',
  styleUrl: './calificacion-edit.component.css'
})
export class CalificacionEditComponent {

}
