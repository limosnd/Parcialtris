import { Component } from '@angular/core';

@Component({
  selector: 'app-calificacion-list',
  templateUrl: './calificacion-list.component.html',
  styleUrl: './calificacion-list.component.css'
})
export class CalificacionListComponent {

}
