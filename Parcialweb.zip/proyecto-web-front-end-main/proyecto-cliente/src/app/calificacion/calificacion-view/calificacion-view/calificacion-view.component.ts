import { Component } from '@angular/core';

@Component({
  selector: 'app-calificacion-view',
  templateUrl: './calificacion-view.component.html',
  styleUrl: './calificacion-view.component.css'
})
export class CalificacionViewComponent {

}
