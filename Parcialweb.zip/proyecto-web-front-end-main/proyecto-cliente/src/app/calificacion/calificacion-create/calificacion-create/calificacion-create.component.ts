import { Component } from '@angular/core';

@Component({
  selector: 'app-calificacion-create',
  templateUrl: './calificacion-create.component.html',
  styleUrl: './calificacion-create.component.css'
})
export class CalificacionCreateComponent {

}
